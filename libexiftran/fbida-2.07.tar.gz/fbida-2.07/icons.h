Pixmap x11_icon_fit(Display *dpy, Pixmap icon, unsigned long bg,
		    int width, int height);
void x11_icons_init(Display *dpy, unsigned long bg);
