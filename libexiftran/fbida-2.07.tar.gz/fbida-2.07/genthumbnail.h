int create_thumbnail(char *filename, unsigned char *dest, int max);
