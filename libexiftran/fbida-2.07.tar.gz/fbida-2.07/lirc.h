int lirc_fbi_init(void);
int lirc_fbi_havedata(int* rc, char key[11]);
